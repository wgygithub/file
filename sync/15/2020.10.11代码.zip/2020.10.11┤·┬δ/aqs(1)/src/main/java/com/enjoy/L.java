package com.enjoy;

public class L {
    //4个字节   4byte 1byte =8bit(0||1)
    int a;
    //1 byte
    boolean f;
}
