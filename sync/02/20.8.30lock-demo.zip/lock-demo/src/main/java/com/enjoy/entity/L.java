package com.enjoy.entity;


/**
 * 对象头
 * 实例数据
 * 对齐填充
 * 位 bit
 * 字节 byte
 * 8bit =1byte
 */
public class L {
    boolean f;
}
