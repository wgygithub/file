package com.enjoy;

public class A {
    byte[] bytes = new byte[1024];
}
