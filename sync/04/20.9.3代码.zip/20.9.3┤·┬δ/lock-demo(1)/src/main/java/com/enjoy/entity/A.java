package com.enjoy.entity;

public class A {
    boolean f;
    byte[] aByte = new byte[1024];
}
